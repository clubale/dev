# ASR-SpotCheck

A lightweight PowerShell script for checking the effective Attack Surface Reduction (ASR) rule configuration on a Windows endpoint.

## What it does

Reads the device's current ASR rule state via `Get-MpPreference`, maps each rule GUID and action code to human-readable labels, and prints a sorted table — no external dependencies or modules required.

**Output columns**

| Column | Description |
|--------|-------------|
| `Rule` | Friendly rule name (e.g. *Block credential stealing from LSASS*) |
| `Mode` | Effective action (`Disabled`, `Audit`, `Block`, `Warn`, `NotConfigured`) |
| `GUID` | Raw rule identifier as stored in the registry |

## Requirements

- Windows 10/11 or Windows Server 2016+
- Microsoft Defender Antivirus (provides `Get-MpPreference`)
- **Elevated PowerShell session** (Run as Administrator)

## Usage

```powershell
powershell -ExecutionPolicy Bypass -File ".\ASR-SpotCheck.ps1"
```

Or from an already-elevated session:

```powershell
.\ASR-SpotCheck.ps1
```

### Example output

```
Rule                                                      Mode  GUID
----                                                      ----  ----
Block credential stealing from LSASS                      Audit 9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2
Block executable content from email & webmail             Block be9ba2d9-53ea-4cdc-84e5-9b1eeee46550
Block execution of potentially obfuscated scripts         Block 5beb7efe-fd9a-4556-801d-275e5ffc04cc
Block persistence through WMI event subscription         Audit e6db77e5-3df2-4cf1-b95a-636979351e5b
...
```

If no ASR rules are configured, the script exits with a warning:

```
WARNING: No ASR rules are configured on this device.
```

## Covered ASR rules

The script recognises all 19 rules available as of Windows 11 24H2 / Defender platform 4.18+:

| Rule name | GUID |
|-----------|------|
| Block abuse of exploited vulnerable signed drivers | `56a863a9-875e-4185-98a7-b882c64b5ce5` |
| Block credential stealing from LSASS | `9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2` |
| Block persistence through WMI event subscription | `e6db77e5-3df2-4cf1-b95a-636979351e5b` |
| Block process creations from PSExec & WMI | `d1e49aac-8f56-4280-b9ba-993a6d77406c` |
| Block executable content from email & webmail | `be9ba2d9-53ea-4cdc-84e5-9b1eeee46550` |
| Block execution of potentially obfuscated scripts | `5beb7efe-fd9a-4556-801d-275e5ffc04cc` |
| Block Adobe Reader from creating child processes | `7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c` |
| Use advanced protection against ransomware | `c1db55ab-c21a-4637-bb3f-a12568109d35` |
| Block JS/VBScript launching downloaded executables | `d3e037e1-3eb8-44c8-a917-57927947596d` |
| Block untrusted/unsigned processes from USB | `b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4` |
| Block all Office apps from creating child processes | `d4f940ab-401b-4efc-aadc-ad5f3c50688a` |
| Block Win32 API calls from Office macros | `92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b` |
| Block Office apps from injecting code into processes | `75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84` |
| Block Office apps from creating executable content | `3b576869-a4ec-4529-8536-b80a7769e899` |
| Block executables unless prevalence/age/trusted-list | `01443614-cd74-433a-b99e-2ecdc07bfc25` |
| Block use of copied or impersonated system tools | `c0033c00-d16d-4114-a5a0-dc9b3a7d2ceb` |
| Block Webshell creation for Servers | `a8f5898e-1dc8-49a9-9878-85004b8a61e6` |
| Block rebooting machine in Safe Mode | `33ddedf1-c6e0-47cb-833e-de6133960387` |
| Block Office communication app from creating child processes | `26190899-1602-49e8-8b27-eb1d0a1ce869` |

Any rule GUID returned by `Get-MpPreference` that is not in the above list is displayed as `(unknown rule)` so the output never silently drops data.

## Related resources

- [Microsoft Docs — Attack Surface Reduction rules reference](https://learn.microsoft.com/en-us/defender-endpoint/attack-surface-reduction-rules-reference)
- [Microsoft Docs — Get-MpPreference](https://learn.microsoft.com/en-us/powershell/module/defender/get-mppreference)
