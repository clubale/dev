# ASR-SpotCheck.ps1
# Per-device check of effective Attack Surface Reduction rule state.
# Pairs the ASR rule IDs with their action values, decodes both, and prints a table.
# Run in an elevated PowerShell session on the target device.
# How to run the script {powershell -ExecutionPolicy Bypass -File ".\ASR-SpotCheck.ps1}

$actionNames = @{
    0 = 'Disabled'
    1 = 'Block'
    2 = 'Audit'
    5 = 'NotConfigured'
    6 = 'Warn'
}

$ruleNames = @{
    '56a863a9-875e-4185-98a7-b882c64b5ce5' = 'Block abuse of exploited vulnerable signed drivers'
    '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2' = 'Block credential stealing from LSASS'
    'e6db77e5-3df2-4cf1-b95a-636979351e5b' = 'Block persistence through WMI event subscription'
    'd1e49aac-8f56-4280-b9ba-993a6d77406c' = 'Block process creations from PSExec & WMI'
    'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550' = 'Block executable content from email & webmail'
    '5beb7efe-fd9a-4556-801d-275e5ffc04cc' = 'Block execution of potentially obfuscated scripts'
    '7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c' = 'Block Adobe Reader from creating child processes'
    'c1db55ab-c21a-4637-bb3f-a12568109d35' = 'Use advanced protection against ransomware'
    'd3e037e1-3eb8-44c8-a917-57927947596d' = 'Block JS/VBScript launching downloaded executables'
    'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4' = 'Block untrusted/unsigned processes from USB'
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a' = 'Block all Office apps from creating child processes'
    '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b' = 'Block Win32 API calls from Office macros'
    '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84' = 'Block Office apps from injecting code into processes'
    '3b576869-a4ec-4529-8536-b80a7769e899' = 'Block Office apps from creating executable content'
    '01443614-cd74-433a-b99e-2ecdc07bfc25' = 'Block executables unless prevalence/age/trusted-list'
    'c0033c00-d16d-4114-a5a0-dc9b3a7d2ceb' = 'Block use of copied or impersonated system tools'
    'a8f5898e-1dc8-49a9-9878-85004b8a61e6' = 'Block Webshell creation for Servers'
    '33ddedf1-c6e0-47cb-833e-de6133960387' = 'Block rebooting machine in Safe Mode'
    '26190899-1602-49e8-8b27-eb1d0a1ce869' = 'Block Office communication app from creating child processes'
}

$pref    = Get-MpPreference
$ids     = @($pref.AttackSurfaceReductionRules_Ids)
$actions = @($pref.AttackSurfaceReductionRules_Actions)

if ($ids.Count -eq 0) {
    Write-Warning "No ASR rules are configured on this device."
    return
}

$results = for ($i = 0; $i -lt $ids.Count; $i++) {
    $guid = [string]$ids[$i]
    $code = [int]$actions[$i]
    [pscustomobject]@{
        Rule = if ($ruleNames.ContainsKey($guid)) { $ruleNames[$guid] } else { '(unknown rule)' }
        Mode = if ($actionNames.ContainsKey($code)) { $actionNames[$code] } else { "Code $code" }
        GUID = $guid
    }
}
$results | Sort-Object Mode, Rule | Format-Table -AutoSize -Wrap